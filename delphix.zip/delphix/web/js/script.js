"use strict";

(function($, window, document){

	$(document).ready(function(){
		// document ready
	});
	
})(jQuery, window, document);


