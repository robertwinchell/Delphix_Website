
<?php include_once("html/header.html"); ?>

    <?php include_once("modules/register_module/module.html"); ?>
    
<?php include_once("html/footer.html"); ?>
