
<?php include_once("html/header.html"); ?>

    <?php include_once("modules/image_module/image_module.html"); ?>

     <?php include_once("modules/text_module/text_module.html"); ?>

     <?php include_once("modules/dynamic_listing-resources/module.html"); ?>

    <?php include_once("modules/demo_delphix_module/module.html"); ?>

    
<?php include_once("html/footer.html"); ?>
