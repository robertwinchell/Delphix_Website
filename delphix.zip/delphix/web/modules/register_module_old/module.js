"use strict";

(function($, window, document) {
    
    function toggleDiv(divId) {
   $("#"+divId).toggle();
}

    $(document).ready(function() {
        $('.nav-toggle').click(function(){
    //logic to show/hide collapsable content
});

    });

})(jQuery, window, document);
