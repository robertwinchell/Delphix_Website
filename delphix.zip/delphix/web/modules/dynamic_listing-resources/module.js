"use strict";

(function($, window, document) {

    var resource_listing = {
        "categories": ["Application Development", "DevOps", "Test Data Management", "Data Masking", "Backup", "ERP Upgrades", "Cloud Migration"],
        "types": ["turpis", "dolor", "finibus"],
        "resources": [{
            "id": 1,
            "title": "Mauris egestas",
            "source": "Vivamus",
            "description": "Pellentesque nec ex eu arcu tempor lobortis",
            "categories": ["DevOps", "Test Data Management"],
            "type": "turpis",
            "image": "\/images\/resource_teaser_1.jpg",
            "link": "\/gated_resource_pdf"
        }, {
            "id": 2,
            "title": "Quisque eget",
            "source": "Mauris",
            "description": "Aliquam scelerisque semper ipsum",
            "categories": ["ERP Upgrades", "Cloud Migration"],
            "type": "dolor",
            "image": "\/images\/resource_teaser_2.jpg",
            "link": "\/gated_resource_video"
        }, {
            "id": 3,
            "title": "Donec nec nibh",
            "source": "Duis",
            "description": "Nullam vitae magna mollis, cursus tellus quis, aliquam diam",
            "categories": ["Backup", "ERP Upgrades"],
            "type": "finibus",
            "image": "\/images\/resource_teaser_3.jpg",
            "link": "\/gated_resource_pdf"
        }, {
            "id": 4,
            "title": "Quisque tincidunt",
            "source": "Cras",
            "description": "Proin a varius elit vestibulum nec fringilla est.",
            "categories": ["Application Development", "DevOps"],
            "type": "turpis",
            "image": "\/images\/resource_teaser_4.jpg",
            "link": "\/gated_resource_video"
        }, {
            "id": 5,
            "title": "Mauris egestas",
            "source": "Vivamus",
            "description": "Pellentesque nec ex eu arcu tempor lobortis",
            "categories": ["DevOps", "Test Data Management"],
            "type": "turpis",
            "image": "\/images\/resource_teaser_1.jpg",
            "link": "\/gated_resource_pdf"
        }, {
            "id": 6,
            "title": "Quisque eget",
            "source": "Mauris",
            "description": "Aliquam scelerisque semper ipsum",
            "categories": ["ERP Upgrades", "Cloud Migration"],
            "type": "dolor",
            "image": "\/images\/resource_teaser_2.jpg",
            "link": "\/gated_resource_video"
        }, {
            "id": 7,
            "title": "Donec nec nibh",
            "source": "Duis",
            "description": "Nullam vitae magna mollis, cursus tellus quis, aliquam diam",
            "categories": ["Backup", "ERP Upgrades"],
            "type": "finibus",
            "image": "\/images\/resource_teaser_3.jpg",
            "link": "\/gated_resource_pdf"
        }, {
            "id": 8,
            "title": "Quisque tincidunt",
            "source": "Cras",
            "description": "Proin a varius elit vestibulum nec fringilla est.",
            "categories": ["Application Development", "DevOps"],
            "type": "turpis",
            "image": "\/images\/resource_teaser_4.jpg",
            "link": "\/gated_resource_video"
        }, {
            "id": 9,
            "title": "Mauris egestas",
            "source": "Vivamus",
            "description": "Pellentesque nec ex eu arcu tempor lobortis",
            "categories": ["DevOps", "Test Data Management"],
            "type": "turpis",
            "image": "\/images\/resource_teaser_1.jpg",
            "link": "\/gated_resource_pdf"
        }, {
            "id": 10,
            "title": "Quisque eget",
            "source": "Mauris",
            "description": "Aliquam scelerisque semper ipsum",
            "categories": ["ERP Upgrades", "Cloud Migration"],
            "type": "dolor",
            "image": "\/images\/resource_teaser_2.jpg",
            "link": "\/gated_resource_video"
        }, {
            "id": 11,
            "title": "Donec nec nibh",
            "source": "Duis",
            "description": "Nullam vitae magna mollis, cursus tellus quis, aliquam diam",
            "categories": ["Backup", "ERP Upgrades"],
            "type": "finibus",
            "image": "\/images\/resource_teaser_3.jpg",
            "link": "\/gated_resource_pdf"
        }, {
            "id": 12,
            "title": "Quisque tincidunt",
            "source": "Cras",
            "description": "Proin a varius elit vestibulum nec fringilla est.",
            "categories": ["Application Development", "DevOps"],
            "type": "turpis",
            "image": "\/images\/resource_teaser_4.jpg",
            "link": "\/gated_resource_video"
        }, {
            "id": 13,
            "title": "Mauris egestas",
            "source": "Vivamus",
            "description": "Pellentesque nec ex eu arcu tempor lobortis",
            "categories": ["DevOps", "Test Data Management"],
            "type": "turpis",
            "image": "\/images\/resource_teaser_1.jpg",
            "link": "\/gated_resource_pdf"
        }, {
            "id": 14,
            "title": "Quisque eget",
            "source": "Mauris",
            "description": "Aliquam scelerisque semper ipsum",
            "categories": ["ERP Upgrades", "Cloud Migration"],
            "type": "dolor",
            "image": "\/images\/resource_teaser_2.jpg",
            "link": "\/gated_resource_video"
        }, {
            "id": 15,
            "title": "Donec nec nibh",
            "source": "Duis",
            "description": "Nullam vitae magna mollis, cursus tellus quis, aliquam diam",
            "categories": ["Backup", "ERP Upgrades"],
            "type": "finibus",
            "image": "\/images\/resource_teaser_3.jpg",
            "link": "\/gated_resource_pdf"
        }, {
            "id": 16,
            "title": "Quisque tincidunt",
            "source": "Cras",
            "description": "Proin a varius elit vestibulum nec fringilla est.",
            "categories": ["Application Development", "DevOps"],
            "type": "turpis",
            "image": "\/images\/resource_teaser_4.jpg",
            "link": "\/gated_resource_video"
        }, {
            "id": 17,
            "title": "Mauris egestas",
            "source": "Vivamus",
            "description": "Pellentesque nec ex eu arcu tempor lobortis",
            "categories": ["DevOps", "Test Data Management"],
            "type": "turpis",
            "image": "\/images\/resource_teaser_1.jpg",
            "link": "\/gated_resource_pdf"
        }, {
            "id": 18,
            "title": "Quisque eget",
            "source": "Mauris",
            "description": "Aliquam scelerisque semper ipsum",
            "categories": ["ERP Upgrades", "Cloud Migration"],
            "type": "dolor",
            "image": "\/images\/resource_teaser_2.jpg",
            "link": "\/gated_resource_video"
        }, {
            "id": 19,
            "title": "Donec nec nibh",
            "source": "Duis",
            "description": "Nullam vitae magna mollis, cursus tellus quis, aliquam diam",
            "categories": ["Backup", "ERP Upgrades"],
            "type": "finibus",
            "image": "\/images\/resource_teaser_3.jpg",
            "link": "\/gated_resource_pdf"
        }, {
            "id": 20,
            "title": "Quisque tincidunt",
            "source": "Cras",
            "description": "Proin a varius elit vestibulum nec fringilla est.",
            "categories": ["Application Development", "DevOps"],
            "type": "turpis",
            "image": "\/images\/resource_teaser_4.jpg",
            "link": "\/gated_resource_video"
        }, {
            "id": 21,
            "title": "Mauris egestas",
            "source": "Vivamus",
            "description": "Pellentesque nec ex eu arcu tempor lobortis",
            "categories": ["DevOps", "Test Data Management"],
            "type": "turpis",
            "image": "\/images\/resource_teaser_1.jpg",
            "link": "\/gated_resource_pdf"
        }, {
            "id": 22,
            "title": "Quisque eget",
            "source": "Mauris",
            "description": "Aliquam scelerisque semper ipsum",
            "categories": ["ERP Upgrades", "Cloud Migration"],
            "type": "dolor",
            "image": "\/images\/resource_teaser_2.jpg",
            "link": "\/gated_resource_video"
        }, {
            "id": 23,
            "title": "Donec nec nibh",
            "source": "Duis",
            "description": "Nullam vitae magna mollis, cursus tellus quis, aliquam diam",
            "categories": ["Backup", "ERP Upgrades"],
            "type": "finibus",
            "image": "\/images\/resource_teaser_3.jpg",
            "link": "\/gated_resource_pdf"
        }, {
            "id": 24,
            "title": "Quisque tincidunt",
            "source": "Cras",
            "description": "Proin a varius elit vestibulum nec fringilla est.",
            "categories": ["Application Development", "DevOps"],
            "type": "turpis",
            "image": "\/images\/resource_teaser_4.jpg",
            "link": "\/gated_resource_video"
        }, {
            "id": 25,
            "title": "Mauris egestas",
            "source": "Vivamus",
            "description": "Pellentesque nec ex eu arcu tempor lobortis",
            "categories": ["DevOps", "Test Data Management"],
            "type": "turpis",
            "image": "\/images\/resource_teaser_1.jpg",
            "link": "\/gated_resource_pdf"
        }, {
            "id": 26,
            "title": "Quisque eget",
            "source": "Mauris",
            "description": "Aliquam scelerisque semper ipsum",
            "categories": ["ERP Upgrades", "Cloud Migration"],
            "type": "dolor",
            "image": "\/images\/resource_teaser_2.jpg",
            "link": "\/gated_resource_video"
        }, {
            "id": 27,
            "title": "Donec nec nibh",
            "source": "Duis",
            "description": "Nullam vitae magna mollis, cursus tellus quis, aliquam diam",
            "categories": ["Backup", "ERP Upgrades"],
            "type": "finibus",
            "image": "\/images\/resource_teaser_3.jpg",
            "link": "\/gated_resource_pdf"
        }, {
            "id": 28,
            "title": "Quisque tincidunt",
            "source": "Cras",
            "description": "Proin a varius elit vestibulum nec fringilla est.",
            "categories": ["Application Development", "DevOps"],
            "type": "turpis",
            "image": "\/images\/resource_teaser_4.jpg",
            "link": "\/gated_resource_video"
        }, {
            "id": 29,
            "title": "Mauris egestas",
            "source": "Vivamus",
            "description": "Pellentesque nec ex eu arcu tempor lobortis",
            "categories": ["DevOps", "Test Data Management"],
            "type": "turpis",
            "image": "\/images\/resource_teaser_1.jpg",
            "link": "\/gated_resource_pdf"
        }, {
            "id": 30,
            "title": "Quisque eget",
            "source": "Mauris",
            "description": "Aliquam scelerisque semper ipsum",
            "categories": ["ERP Upgrades", "Cloud Migration"],
            "type": "dolor",
            "image": "\/images\/resource_teaser_2.jpg",
            "link": "\/gated_resource_video"
        }, {
            "id": 31,
            "title": "Donec nec nibh",
            "source": "Duis",
            "description": "Nullam vitae magna mollis, cursus tellus quis, aliquam diam",
            "categories": ["Backup", "ERP Upgrades"],
            "type": "finibus",
            "image": "\/images\/resource_teaser_3.jpg",
            "link": "\/gated_resource_pdf"
        }, {
            "id": 32,
            "title": "Quisque tincidunt",
            "source": "Cras",
            "description": "Proin a varius elit vestibulum nec fringilla est.",
            "categories": ["Application Development", "DevOps"],
            "type": "turpis",
            "image": "\/images\/resource_teaser_4.jpg",
            "link": "\/gated_resource_video"
        }]
    }

    $(document).ready(function() {
        // document ready
        var div = $("<div class=\"container\">").appendTo("#list");

        var lastID;

        $(resource_listing.resources).each(function (index, item) {
            div.append("<div data-tile-id=\""+item.id+"\" class=\"tiles col-md-4\">" +
                    "<div class=\"tile-top\">" +
                        "<img src=\""+item.image+"\" alt=\""+item.title+"\">" +
                    "</div>" +
                    "<div class=\"tile-bottom\">" +
                        "<span class=\"tile-source\">"+item.source+"</span>" +
                        "<span class=\"tile-title\">"+item.title+"</span>" +
                        "<p class=\"tile-description\">"+item.description+"</p>" +
                        "<a class=\"tile-link\" href=\""+item.link+"\">Call to Action here <span class=\"glyphicon glyphicon-circle-arrow-right\" aria-hidden=\"true\"></span></a>" +
                    "</div>" +
                "</div>");

            window.lastID = index;

            return index<11;
        });

        var $targetCategory = $('#targetCategory');
        $targetCategory.append("<span class=\"filter-item-dp-item\" data-target=\"category\">Category</span>");
        var $targetType = $('#targetType');
        $targetType.append("<span class=\"filter-item-dp-item\" data-target=\"type\">Type</span>");

        $(resource_listing.categories).each(function (index, item) {
            $targetCategory.append("<span class=\"filter-item-dp-item\" data-target=\"category\">"+item+"</span>");
        });

        $(resource_listing.types).each(function (index, item) {
            $targetType.append("<span class=\"filter-item-dp-item\" data-target=\"type\">"+item+"</span>");
        });

        $('span[data-action="load-more"]').click(function() {
            var beforeLastID = window.lastID;
            var div = $('div.container');
            $(resource_listing.resources).each(function  (index, item) {
                if (index > window.lastID) {
                    div.append("<div data-tile-id=\""+item.id+"\" class=\"tiles col-md-4\">" +
                        "<div class=\"tile-top\">" +
                        "<img src=\""+item.image+"\" alt=\""+item.title+"\">" +
                        "</div>" +
                        "<div class=\"tile-bottom\">" +
                        "<span class=\"tile-source\">"+item.source+"</span>" +
                        "<span class=\"tile-title\">"+item.title+"</span>" +
                        "<p class=\"tile-description\">"+item.description+"</p>" +
                        "<a class=\"tile-link\" href=\""+item.link+"\">Call to Action here <span class=\"glyphicon glyphicon-circle-arrow-right\" aria-hidden=\"true\"></span></a>" +
                        "</div>" +
                        "</div>");

                    window.lastID = index;

                    return index<(12 + beforeLastID);
                }
            });
        });

        $('.filter-item').bind("mouseenter mouseleave", function() {
            $(this).find('.filter-item-dp').toggleClass('dp-show');
        });

        $('body').on('click', '.filter-item-dp-item', function() {
            var target = $(this).attr('data-target');

            $('#' + target).text($(this).text());

            filter_items();
        });

        $('#keyword').on('input', function() {
            filter_items();
        });

        $('#filterSubmit').click(function() {
            filter_items();
        });

        function filter_items() {
            var category = $('#category').text();
            var type = $('#type').text();
            var keyword = $('#keyword').val();
            var div = $('#list > div');

            $(resource_listing.resources).each(function (index, item) {
                var categoryCustom = false, typeCustom = false, keywordCustom = false;
                if (category != "Category") {
                    categoryCustom = true;

                    if ($.inArray(category, item.categories) == -1) {
                        if ($('.tiles[data-tile-id="'+item.id+'"]').length) {
                            $('.tiles[data-tile-id="'+item.id+'"]').attr('data-tile-wait', 'delete');
                        }
                        return true;
                    }
                }

                if (type != "Type") {
                    typeCustom = true;

                    if (type != item.type) {
                        if ($('.tiles[data-tile-id="'+item.id+'"]').length) {
                            $('.tiles[data-tile-id="'+item.id+'"]').attr('data-tile-wait', 'delete');
                        }
                        return true;
                    }
                }

                if (keyword != "") {
                    keywordCustom = true;

                    if ((item.title.toLowerCase().indexOf(keyword.toLowerCase()) == -1) && (item.description.toLowerCase().indexOf(keyword.toLowerCase()) == -1)) {
                        if ($('.tiles[data-tile-id="'+item.id+'"]').length) {
                            $('.tiles[data-tile-id="'+item.id+'"]').attr('data-tile-wait', 'delete');
                        }
                        return true;
                    }
                }

                div.append("<div data-tile-wait=\"create\" data-tile-id=\""+item.id+"\" class=\"tiles col-md-4\" style=\"display: none;\">" +
                    "<div class=\"tile-top\">" +
                    "<img src=\""+item.image+"\" alt=\""+item.title+"\">" +
                    "</div>" +
                    "<div class=\"tile-bottom\">" +
                    "<span class=\"tile-source\">"+item.source+"</span>" +
                    "<span class=\"tile-title\">"+item.title+"</span>" +
                    "<p class=\"tile-description\">"+item.description+"</p>" +
                    "<a class=\"tile-link\" href=\""+item.link+"\">Call to Action here <span class=\"glyphicon glyphicon-circle-arrow-right\" aria-hidden=\"true\"></span></a>" +
                    "</div>" +
                    "</div>");

                if (categoryCustom || typeCustom || keywordCustom)
                {
                    $('span[data-action="load-more"]').css('display', 'none');
                }
                else
                {
                    $('span[data-action="load-more"]').css('display', 'block');

                    window.lastID = index;

                    return index<11;
                }
            });

            div.find('.tiles[data-tile-wait="delete"]').slideUp("normal", function () {
                div.find('.tiles[data-tile-wait="create"]').slideDown("normal");
            });
        }
    });

})(jQuery, window, document);
