
<?php include_once("html/header.html"); ?>

	<?php include_once("modules/sample_1/module.html"); ?>
    
<?php include_once("html/footer.html"); ?>
